Example application. Does not make requests to APIs -- uses .JSON data files representing data you could possibly get from YouTube and Spotify, and shows examples of using templates to embed them.

Code originally written by @anandpdoshi.
